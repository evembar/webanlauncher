from customtkinter import *
from pygame import mixer
import wget
from tkinter import PhotoImage
import os.path
from random import randint
import webbrowser
import engine_downloader as edg

play_mus = True


def start():
    gui()

def gui():
    

    def start_menu_launch():
        logo_label.place_forget()
        studio_label.place_forget()
        menu_launch()

    def musrand_play():
        musrand = randint(1,6)

        if play_mus == True:
            if musrand == 1:
                mixer.music.load('src/theme 1.ogg')
                mixer.music.play(-1)
            elif musrand == 2:
                mixer.music.load('src/theme 2.ogg')
                mixer.music.play(-1)
            elif musrand == 3:
                mixer.music.load('src/world 2.ogg')
                mixer.music.play(-1)
            elif musrand == 4:
                mixer.music.load('src/project_2.mp3')
                mixer.music.play(-1)
            elif musrand == 5:
                mixer.music.load('src/theme 3.ogg')
                mixer.music.play(-1)
            elif musrand == 6:
                mixer.music.load('src/theme 4.ogg')
                mixer.music.play(-1)
        elif play_mus == False:
            mixer.music.stop()

    def menu_launch():
        global get_right_left, xgl, game_number, game_image, about_click, reboot_click, support_click, gamepath, dowde_click, upda_click, dowde_frame, fonter

        about_en_image = PhotoImage(file='src/about/about_en.png')
        about_ru_image = PhotoImage(file='src/about/about_ru.png')
        left_image = PhotoImage(file='src/left.png')
        right_image = PhotoImage(file='src/right.png')
        play_ru_image = PhotoImage(file='src/play/play_ru.png')
        play_en_image = PhotoImage(file='src/play/play_en.png')
        lang_en_image = PhotoImage(file='src/lang/lang_en.png')
        lang_ru_image = PhotoImage(file='src/lang/lang_ru.png')
        sound_on_ru = PhotoImage(file='src/sound/on/sound_on_ru.png')
        sound_off_ru = PhotoImage(file='src/sound/off/sound_off_ru.png')
        sound_on_en = PhotoImage(file='src/sound/on/sound_on_en.png')
        sound_off_en = PhotoImage(file='src/sound/off/sound_off_en.png')
        anfull = PhotoImage(file='src/game_preview/anfull.png')
        andlc = PhotoImage(file='src/game_preview/andlc.png')
        nightsoul = PhotoImage(file='src/game_preview/nightsoul.png')
        ortano = PhotoImage(file='src/game_preview/ortano.png')
        about_game_en = PhotoImage(file='src/about_game/about_game_en.png')
        about_game_ru = PhotoImage(file='src/about_game/about_game_ru.png')
        support_en = PhotoImage(file='src/support/support_en.png')
        support_ru = PhotoImage(file='src/support/support_ru.png')
        stop_en = PhotoImage(file='src/stop/stop_en.png')
        stop_ru = PhotoImage(file='src/stop/stop_ru.png')
        delete_game_image_en = PhotoImage(file='src/delete/delete_en.png')
        delete_game_image_ru = PhotoImage(file='src/delete/delete_ru.png')
        update_en = PhotoImage(file='src/update/update_en.png')
        update_ru = PhotoImage(file='src/update/update_ru.png')
        
        
        
        game_image=anfull
        game_number=1
        get_right_left=1
        about_click=0
        reboot_click=0
        support_click=0
        dowde_click=0
        upda_click=0
        
        xgl=145.0

        def game_right():   
            global get_right_left, xgl, game_image, game_number, gamepath    
            if get_right_left == 1:
                get_right_left = 0
                for i in range(20):
                    des.after(30)
                    xgl +=32.75
                    game_button.place(x=xgl, y=80)
                    des.update()
                
                if game_number == 1:
                    game_number = 2
                    game_image=nightsoul
                    gamepath = 'nightsoul'
                elif game_number == 2:
                    game_number = 3
                    game_image = ortano
                    gamepath = 'ortano'
                elif game_number == 3:
                    game_number = 4
                    game_image = andlc
                    gamepath = 'andlc'
                elif game_number == 4:
                    game_number = 1
                    game_image = anfull
                    gamepath = 'anfull'

                if game_number == 1:
                    play_button.place(x=355, y=430)
                elif game_number == 2:
                    play_button.place(x=355, y=430)
                elif game_number == 3:
                    play_button.place_forget()
                elif game_number == 4:
                    play_button.place_forget()

                xgl=-645.0
                game_button.place(x=xgl,y=80)
                game_button.configure(image = game_image)
                des.update()
                des.after(30)
                for i in range(20):
                    des.after(30)
                    xgl+=39.5
                    game_button.place(x=xgl,y=80)
                    des.update()

                delete_showhider = edg.game_verify(gamepath=gamepath)

                if delete_showhider == True:
                    delete_game_button.place(x=355, y=20)
                elif delete_showhider == False:
                    delete_game_button.place_forget()

                get_right_left = 1
            elif get_right_left == 0:
                pass

        def get_verity():
            global gamepath
            delete_showhider = edg.game_verify(gamepath=gamepath)

            if delete_showhider == True:
                delete_game_button.place(x=355, y=20)
            elif delete_showhider == False:
                delete_game_button.place_forget()

        def game_left():   
            global get_right_left, xgl, game_image, game_number,gamepath    
            if get_right_left == 1:
                get_right_left = 0
                for i in range(20):
                    des.after(30)
                    xgl -=39.5
                    game_button.place(x=xgl, y=80)
                    des.update()
                
                if game_number == 1:
                    game_number = 4
                    game_image=andlc
                    gamepath = 'andlc'
                elif game_number == 2:
                    game_number = 1
                    game_image = anfull
                    gamepath = 'anfull'
                elif game_number == 3:
                    game_number = 2
                    game_image = nightsoul
                    gamepath='nightsoul'
                elif game_number == 4:
                    game_number = 3
                    game_image = ortano
                    gamepath = 'ortano'

                if game_number == 1:
                    play_button.place(x=355, y=430)
                elif game_number == 2:
                    play_button.place(x=355, y=430)
                elif game_number == 3:
                    play_button.place_forget()
                elif game_number == 4:
                    play_button.place_forget()

                xgl=800.0
                game_button.place(x=xgl,y=80)
                game_button.configure(image = game_image)
                des.update()
                des.after(30)
                for i in range(20):
                    des.after(30)
                    xgl-=32.75
                    game_button.place(x=xgl,y=80)
                    des.update()

                delete_showhider = edg.game_verify(gamepath=gamepath)

                if delete_showhider == True:
                    delete_game_button.place(x=355, y=20)
                elif delete_showhider == False:
                    delete_game_button.place_forget()

                get_right_left = 1
            elif get_right_left == 0:
                pass

        system_os = edg.system_check()
        if system_os == 'nt':
            enfont = ('Segoe UI Light', 21)
            rufont = ('Segoe UI Light', 20)
            fonter = 'Segoe UI Light'
        elif system_os == 'posix':
            enfont = ('Ubuntu Light', 21)
            rufont = ('Ubuntu Light', 20)
            fonter = 'Ubuntu Light'
        
        if os.path.isfile('setting.py'):
            import setting
            if setting.lang == "en":
                about_image = about_en_image
                play_image = play_en_image
                lang_image = lang_en_image
                sound_on = sound_on_en
                sound_off = sound_off_en
                sound_im = sound_on
                about_game = about_game_en
                text_anfull='Game name: Anonymous. In search of snus full version\nPublish date: 15 April 2023\nDescription: Anonymous person who wants to give his pet a gift. So he goes on an amazing adventure.'
                text_andlc='Game name: Anonymous DLC. The secret of snus\nPublish date: Comming soon\nDescription: Coming soon'
                text_nightsoul='Game name: Night soul\nPublish date: 15 August 2023\nDescription: Night. You wake up in one place, but you are aware of it. You have to understand this phenomenon in many ways as a dream. '
                text_ortano='Game name: ORTANO\nPublish date: Comming soon\nDescription: Comming soon'
                font_game_about = enfont
                support_image = support_en
                donas='https://evembar.github.io/webanlimaks/support_en.html'
                stop = stop_en
                delete_game_image = delete_game_image_en
                download_msg = '         Downloading package...\n     Please wait!'
                dowde = '         Error Downloading package!'
                update_image = update_en
                update_text = '                  Launcher updated!'
            elif setting.lang == "ru":
                about_image = about_ru_image
                play_image = play_ru_image
                lang_image = lang_ru_image
                sound_on = sound_on_ru
                sound_off = sound_off_ru
                sound_im = sound_on
                about_game = about_game_ru
                text_anfull='Название игры: Anonymous. In search of snus full version\nДата релиза: 15 Апреля 2023\nОписание: Анонимус хочет подарить снюсоеду подарок. Вы отправляетесь в приключение, чтобы найти снюс.'
                text_andlc='Название игры: Anonymous DLC. The secret of snus\nДата релиза: Скоро\nОписание: Скоро'
                text_ortano='Название игры: ORTANO\nДата релиза: Скоро\nОписание: Скоро'
                text_nightsoul='Название игры: Night soul\nДата релиза: 15 Августа 2023\nОписание: Ночь. Вы просыпайтесь в каком-то месте и осознаёте это. Вам предстоит разобраться об явлении как сон.'
                font_game_about = rufont
                support_image = support_ru
                donas='https://evembar.github.io/webanlimaks/support_ru.html'
                stop = stop_ru
                delete_game_image = delete_game_image_ru
                download_msg = '       Скачивание пакетов...\n   Пожалуйста, подождите!'
                dowde = '         Ошибка скачивания пакетов!'
                update_image = update_ru
                update_text = '                Лаунчер обновлен!'
        else:
            settinger = open('setting.py', 'w+')
            settinger.write('lang = "en"')
            settinger.close()
            import setting
            menu_launch()

        def msg_reboot():
            global msgreb_frame, reboot_click

            if reboot_click == 0:
                
                reboot_click = 1

                def hide_reboot_frame():
                    global msgreb_frame
                    msgreb_frame.place_forget()

                ok_image = PhotoImage(file='src/ok.png')

                msgreb_frame = CTkFrame(des, width=400, height=200, corner_radius=0, bg_color='#212121', fg_color='#212121')
                msgreb_frame.place(x=200, y=150)

                reboot_info_label = CTkLabel(msgreb_frame, text_color='white', text='  Please reboot WebAnLauncher 2\n Пожалуйста, перезагрузите WebAnLauncher 2', font=(f'{fonter}', 18))
                reboot_info_label.place(x = 15, y = 30)
                
                ok_button = CTkButton(msgreb_frame, image=ok_image, text='', width=100, height=40, bg_color='#212121', fg_color='#212121', hover_color='#212121', command=hide_reboot_frame)
                ok_button.place(x=300, y=150)
            elif reboot_click == 1:
                pass

        def msg_about():
            global msg_frame, about_click

            if about_click == 0:
                about_click = 1

                def hide_msg_info():
                    global msg_frame, about_click
                    msg_frame.place_forget()
                    about_click = 0

                ok_image = PhotoImage(file='src/ok.png')
                logo_small = PhotoImage(file='src/logo_small.png')

                msg_frame = CTkFrame(des, width=400, height=200, corner_radius=0, bg_color='#212121', fg_color='#212121')
                msg_frame.place(x=200, y=150)

                studio_info_label = CTkLabel(msg_frame, text_color='white',  text='           WebAnlauncher 2\n          WebAnLiMaks studios 2023', font=(f'{fonter}', 21))
                studio_info_label.place(x = 15, y = 30)

                logo_small_button = CTkLabel(msg_frame, text_color='white',  image=logo_small, text='', width=100, height=40, bg_color='black', fg_color='black')
                logo_small_button.place(x=155, y=100)

                version_info_label = CTkLabel(msg_frame, text_color='white',  text='ver 0.1.1 Beta', font=(f'{fonter}', 21))
                version_info_label.place(x = 147, y = 170)
                
                ok_button = CTkButton(msg_frame, image=ok_image, text='', width=100, height=50, bg_color='#212121', fg_color='#212121', hover_color='#212121', command=hide_msg_info)
                ok_button.place(x=300, y=150)
            elif about_click == 1:
                pass

        def msg_dowde(text_update=None):
            global dowde_frame, dowde_click

            if dowde_click == 0:
                dowde_click = 1

                def hide_msg_info():
                    global msg_frame, dowde_click
                    dowde_frame.place_forget()
                    dowde_click = 0

                ok_image = PhotoImage(file='src/ok.png')
                logo_small = PhotoImage(file='src/logo_small.png')

                dowde_frame = CTkFrame(des, width=400, height=200, corner_radius=0, bg_color='#212121', fg_color='#212121')
                dowde_frame.place(x=200, y=150)

                if text_update==None:
                    dowde_text=dowde
                else:
                    dowde_text=text_update

                studio_info_label = CTkLabel(dowde_frame, text_color='white',  text=dowde_text, font=(f'{fonter}', 21))
                studio_info_label.place(x = 15, y = 30)

                logo_small_button = CTkLabel(dowde_frame, text_color='white',  image=logo_small, text='', width=100, height=40, bg_color='black', fg_color='black')
                logo_small_button.place(x=155, y=100)
                
                dowde_ok_button = CTkButton(dowde_frame, image=ok_image, text='', width=100, height=50, bg_color='#212121', fg_color='#212121', hover_color='#212121', command=hide_msg_info)
                dowde_ok_button.place(x=300, y=150)
            elif dowde_click == 1:
                pass

        def msg_support():
            global msg_support_frame, support_click

            if support_click == 0:
                support_click = 1

                def hide_msg_info():
                    global msg_frame, support_click
                    msg_support_frame.place_forget()
                    support_click = 0

                ok_image = PhotoImage(file='src/ok.png')

                msg_support_frame = CTkFrame(des, width=400, height=200, corner_radius=0, bg_color='#212121', fg_color='#212121')
                msg_support_frame.place(x=200, y=150)

                studio_info_label = CTkLabel(msg_support_frame, text_color='white',  text='Donut/Донат:\n\nSite/Сайт:\n\nContact/Связь:', font=(f'{fonter}', 21))
                studio_info_label.place(x = 20, y = 10)

                get_donat_button = CTkButton(msg_support_frame, text='Donut/Донат', corner_radius=0,  bg_color='#212121', fg_color='#212121', hover_color='#212121', font=('Arial', 16), command=lambda: webbrowser.open_new_tab(donas))
                get_donat_button.place(x=200,y=15)

                get_site_button = CTkButton(msg_support_frame, text='Site/Сайт', corner_radius=0,  bg_color='#212121', fg_color='#212121', hover_color='#212121', font=('Arial', 16), command=lambda: webbrowser.open_new_tab('https://evembar.github.io/webanlimaks'))
                get_site_button.place(x=200,y=72)

                get_site_button = CTkButton(msg_support_frame, text='Contact/Связь', corner_radius=0,  bg_color='#212121', fg_color='#212121', hover_color='#212121', font=('Arial', 16), command=lambda: webbrowser.open_new_tab('https://t.me/Original_Maksimys'))
                get_site_button.place(x=200,y=130)

                ok_button = CTkButton(msg_support_frame, image=ok_image, text='', width=100, height=50, bg_color='#212121', fg_color='#212121', hover_color='#212121', command=hide_msg_info)
                ok_button.place(x=300, y=150)
            elif support_click == 1:
                pass

        def get_update():
            download_msg_frame()
            des.update()
            update_verity = edg.get_update_verity(ver=0.11)
            if update_verity == 'reboot':
                des.destroy()
                mixer.music.unload()
                edg.install_update()
            elif update_verity == 'error':
                dow_support_frame.place_forget()
                msg_dowde()
                des.update()
            if update_verity == 'stable':
                dow_support_frame.place_forget()
                msg_dowde(text_update=update_text)
                des.update()

        def hide_about_game_info():
            global xgl, msg_about_game_frame, get_right_left, about_click, reboot_click, support_click, dowde_click, upda_click
            msg_about_game_frame.place_forget()
            
            for i in range(20):
                des.after(30)
                xgl +=7.25
                game_button.place(x=xgl,y=80)
                des.update()
            about_button.place(x=675, y=30)
            left_button.place(x=-5, y=250)
            right_button.place(x=750, y=250)
            if game_number == 1:
                play_button.place(x=355, y=430)
            elif game_number == 2:
                play_button.place(x=355, y=430)
            elif game_number == 3:
                play_button.place_forget()
            elif game_number == 4:
                play_button.place_forget()
            sound_button.place(x=490, y=430)
            about_game_button.place(x=675, y=430)
            support_button.place(x=550, y=30)
            update_launcher_button.place(x=5, y=430)
            get_right_left = 1
            about_click = 0
            support_click = 0
            dowde_click = 0
            upda_click = 0
            if reboot_click == 0:
                lang_button.place(x=220, y=430)
            elif reboot_click == 1:
                pass

        def download_msg_frame():
            global dow_support_frame
            dow_support_frame = CTkFrame(des, width=400, height=200, corner_radius=0, bg_color='#212121', fg_color='#212121')
            dow_support_frame.place(x=200, y=150)
            studio_info_label = CTkLabel(dow_support_frame, text_color='white',  text=download_msg, font=(f'{fonter}', 21))
            studio_info_label.place(x = 70, y = 50)


        def play_game():
            global get_right_left,dow_support_frame, game_number, play_mus, gamepath
            
            if get_right_left == 1:
                get_right_left = 0

                if game_number == 1:
                    game_verity = edg.game_verify(gamepath='anfull')
                    if game_verity == False:
                        download_msg_frame()
                        des.update()
                    try:
                        game_pul_verif = edg.game_init(gamepath='anfull')
                        get_verity()
                        try:
                            dow_support_frame.place_forget()
                        except:
                            pass
                        play_button.configure(image=stop)
                        des.update()
                        if play_mus == True:
                            sound_refacter()
                        game_pul_start = edg.game_start(gamepath='anfull')
                        sound_refacter()
                        play_button.configure(image=play_image)
                        des.update()
                    except:
                        try:
                            dow_support_frame.place_forget()
                        except:
                            pass
                        msg_dowde()
                    des.update()
                    get_right_left = 1
                elif game_number == 2:
                    game_verity = edg.game_verify(gamepath='nightsoul')
                    if game_verity == False:
                        download_msg_frame()
                        des.update()
                    try:
                        game_pul_verif = edg.game_init(gamepath='nightsoul')
                        get_verity()
                        try:
                            dow_support_frame.place_forget()
                        except:
                            pass
                        play_button.configure(image=stop)
                        des.update()
                        if play_mus == True:
                            sound_refacter()
                        game_pul_start = edg.game_start(gamepath='nightsoul')
                        sound_refacter()
                        play_button.configure(image=play_image)
                        des.update()
                    except:
                        try:
                            dow_support_frame.place_forget()
                        except:
                            pass
                        msg_dowde()
                    des.update()
                    get_right_left = 1
                else:
                   get_right_left = 1 
            elif get_right_left == 0:
                pass

        def delete_game():
            global game_number
            if game_number == 1:
                edg.delete_game(gamepath='anfull')
                delete_game_button.place_forget()
            if game_number == 2:
                edg.delete_game(gamepath='nightsoul')
                delete_game_button.place_forget()

        def about_game_info():
            global get_right_left, game_number, xgl, msg_about_game_frame, msg_frame, msgreb_frame, msg_support_frame, dowde_frame
            
            if get_right_left == 1:

                try:
                    msg_frame.place_forget()
                except:
                    pass
                try:
                    msgreb_frame.place_forget()
                except:
                    pass
                try:
                    msg_support_frame.place_forget()
                except:
                    pass
                try:
                    dowde_frame.place_forget()
                except:
                    pass

                get_right_left = 0
                right_button.place_forget()
                left_button.place_forget()
                lang_button.place_forget()
                play_button.place_forget()
                sound_button.place_forget()
                about_button.place_forget()
                about_game_button.place_forget()
                support_button.place_forget()
                delete_game_button.place_forget()
                update_launcher_button.place_forget()
                for i in range(20):
                    des.after(30)
                    xgl -=7.25
                    game_button.place(x=xgl,y=80)
                    des.update()
                if game_number == 1:
                    game_text = text_anfull
                elif game_number == 2:
                    game_text = text_nightsoul
                elif game_number == 3:
                    game_text = text_ortano
                elif game_number == 4:
                    game_text = text_andlc
                msg_about_game_frame = CTkFrame(des, width=276, height=303, corner_radius=0, bg_color='black', fg_color='black', border_color='#ffffff', border_width=3)
                msg_about_game_frame.place(x=514, y=84)
                button_about_game_ok = CTkButton(msg_about_game_frame, width=80, height=32, corner_radius=0, bg_color='black', fg_color='black', border_color='#ffffff', hover_color="black", border_width=3, text='OK', font=('Arial', 17), command=hide_about_game_info)
                button_about_game_ok.place(x=194,y=270)
                about_game_label=CTkLabel(msg_about_game_frame, text_color='white',  wraplength=265, text=game_text, font=font_game_about)
                about_game_label.place(x=10,y=5)
                
            elif get_right_left == 0:
                pass

        def change_lang():
            import setting
            if setting.lang == "en":
                os.remove('setting.py')
                settinger = open('setting.py', 'w+')
                settinger.write('lang = "ru"')
                settinger.close()
                import setting
            elif setting.lang == "ru":
                os.remove('setting.py')
                settinger = open('setting.py', 'w+')
                settinger.write('lang = "en"')
                settinger.close()
                import setting
            lang_button.place_forget()
            msg_reboot()

        def sound_refacter():
            global sound_im, play_mus
            if play_mus == False:
                play_mus = True
                sound_im = sound_on
                sound_button.configure(image = sound_im)
                des.update()
                musrand_play()
            elif play_mus == True:
                play_mus = False
                sound_im = sound_off
                sound_button.configure(image = sound_im)
                des.update()
                musrand_play()

        about_button = CTkButton(des, image=about_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=msg_about)
        about_button.place(x=675, y=30)

        left_button = CTkButton(des, image=left_image, text='', width=40, height=40, bg_color='black', fg_color='black', hover_color='black', command=game_left)
        left_button.place(x=-5, y=250)

        right_button = CTkButton(des, image=right_image, text='', width=40, height=40, bg_color='black', fg_color='black', hover_color='black', command=game_right)
        right_button.place(x=750, y=250)

        play_button = CTkButton(des, image=play_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=play_game)
        play_button.place(x=355, y=430)

        lang_button = CTkButton(des, image=lang_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=change_lang)
        lang_button.place(x=220, y=430)

        sound_button = CTkButton(des, image=sound_im, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=sound_refacter)
        sound_button.place(x=490, y=430)

        game_button = CTkButton(des, width=500, height=325, text='', image=game_image, bg_color='black', fg_color='black', hover_color='black', command=play_game)
        game_button.place(x=xgl, y=80)

        about_game_button = CTkButton(des, image=about_game, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=about_game_info)
        about_game_button.place(x=675, y=430)

        support_button = CTkButton(des, image=support_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=msg_support)
        support_button.place(x=550, y=30)

        delete_game_button = CTkButton(des, image=delete_game_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=delete_game)

        update_launcher_button = CTkButton(des, image=update_image, text='', width=100, height=40, bg_color='black', fg_color='black', hover_color='black', command=get_update)
        update_launcher_button.place(x=5, y=430)
        
        gamepath = 'anfull'

        delete_showhider = edg.game_verify(gamepath=gamepath)

        if delete_showhider == True:
            delete_game_button.place(x=355, y=20)
        elif delete_showhider == False:
            delete_game_button.place_forget()
        musrand_play()

    def boot():
        global logo_label, studio_label

        mixer.init()
        mixer.music.load('src/startup.ogg')
        mixer.music.play()
        logo=PhotoImage(file='src/logo.png')
        logo_label=CTkLabel(des, image=logo, text='')
        studio_label=CTkLabel(des, text_color='white',  text='WebAnLauncher 2', font=(f'{fonter}', 30), bg_color='black')
        yl1=900
        studio_label.place(x=270, y=yl1)
        yl=-300
        logo_label.place(x=200, y=yl)
        des.update()
        for i in range(17):
            des.after(40)
            yl+=20
            logo_label.place(x=260, y=yl)
            des.update()
        des.after(1000)
        yl1 = 400
        studio_label.place(x=270, y=yl1)
        des.update()
        des.after(5000, start_menu_launch)

    system_os = edg.system_check()
    if system_os == 'nt':
        fonter = 'Segoe UI Light'
    elif system_os == 'posix':
        fonter = 'Ubuntu Light'

    des=CTk()
    des.title('WebAnLauncher 2')
    des.geometry('800x500')
    try:
        des.iconbitmap('src/iconbitmap/logo.ico')
    except:
        pass
    des.resizable(width=False, height=False)

    

    des.after(3000, boot)

    bg = PhotoImage(file='src/bg.png')

    bg_label = CTkLabel(des, text='', image=bg)
    bg_label.place(x=0,y=0)

    des.mainloop()
