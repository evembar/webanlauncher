import os
import shutil
import wget
import get_game_list as ggs
from threading import Thread
import subprocess
import time
import engine
from importlib import reload

game_platform = os.name

def system_check():
    return game_platform

def game_check(gamepath):

    

    if game_platform == 'nt':
        print('Use Microsoft Windows')
    elif game_platform == 'posix':
        print('Use Unix based system')

    game_info = ggs.set_game(game=gamepath, platform = game_platform)

    if os.path.isdir('download_game/'):
        if os.path.isdir(f'download_game/{game_info[1]}'):
            if os.path.isfile(f'download_game/{game_info[1]}/{game_info[0]}'):
                return 'ok'
            else:
                shutil.rmtree(f'download_game/{game_info[1]}')
                wget.download(game_info[2], 'download_game/')
                time.sleep(0.1)
                os.rename(f'download_game/{game_info[3]}',f'download_game/{gamepath}.zip')
                time.sleep(0.1)
                shutil.unpack_archive(f'download_game/{gamepath}.zip', 'download_game')
                time.sleep(0.1)
                os.remove(f'download_game/{gamepath}.zip')
                return 'ok'
        else:
            wget.download(game_info[2], f'download_game/{game_info[3]}')
            time.sleep(0.1)
            os.rename(f'download_game/{game_info[3]}',f'download_game/{gamepath}.zip')
            time.sleep(0.1)
            shutil.unpack_archive(f'download_game/{gamepath}.zip', 'download_game')
            time.sleep(0.1)
            os.remove(f'download_game/{gamepath}.zip')
            return 'ok'
    else:
        os.mkdir('download_game/')
        wget.download(game_info[2], 'download_game/')
        time.sleep(0.1)
        os.rename(f'download_game/{game_info[3]}',f'download_game/{gamepath}.zip')
        time.sleep(0.1)
        shutil.unpack_archive(f'download_game/{gamepath}.zip', 'download_game')
        time.sleep(0.1)
        os.remove(f'download_game/{gamepath}.zip')
        return 'ok'


def game_start(gamepath):
    game_platform = os.name
    game = ggs.set_game(game=gamepath, platform=game_platform)

    if game_platform == 'nt':
        with subprocess.Popen([f'download_game/{game[1]}/{game[0]}']) as game_proc:
            game_proc.communicate()
            return 'ok'
    elif game_platform == 'posix':
        os.system(f'sudo chmod +x download_game/{game[1]}/{game[0]}')
        

def start_posix(gamepath):
    game = ggs.set_game(game=gamepath, platform=game_platform)
    os.system(f'./download_game/{game[1]}/{game[0]}')
    return 'ok'

def game_init(gamepath):

    game_check(gamepath=gamepath)

def game_verify(gamepath):
    
    game_select = ggs.set_game(game=gamepath, platform=game_platform)
    
    if os.path.isdir(f'download_game/{game_select[1]}'):
        return True
    else:
        return False
        
def delete_game(gamepath):
    game_select = ggs.set_game(game=gamepath, platform=game_platform)
    shutil.rmtree(f'download_game/{game_select[1]}')
    return True
        
def get_update_verity(ver):
    if os.path.isfile('update_list.py'):
        os.remove('update_list.py')
    else:
        pass
    try:
        wget.download('https://github.com/evembar/webanlauncher/raw/main/update_list.py')
        import update_list
        version_update = update_list.get_version(ver=ver)
        if version_update == 'no update':
            print('Use stable version launcher')
            return 'stable'
        elif version_update == 'update':
            if os.path.isfile('update.zip'):
                os.remove('update.zip')
            else:
                pass
            wget.download(f'{update_list.update_link}')
            
            return 'reboot'
    except:
        print('error')
        return 'error'
    
def install_update():
    print('\nInstalling update for launcher')
    shutil.unpack_archive('update.zip')
    os.remove('update.zip')
    print('reboot')
    reload(engine)
    import start
    return 'ok'
        

