def set_game(game, platform):
    
    if game == 'anfull':

        print('Use Anonymous. In search of snus full version')

        if platform == 'nt':
            
            game_link = 'https://github.com/evembar/webanlauncher/releases/download/o/anonymous_windows.webanlimax'

            game_exec = 'anonymous.exe'

            game_path = 'Anonymous-full'

            game_package = 'anonymous_windows.webanlimax'

        elif platform == 'posix':

            game_link = 'https://github.com/evembar/webanlauncher/releases/download/o/anonymous_linux.webanlimax'

            game_exec = 'anonymous'

            game_path = 'Anonymous-full'

            game_package = 'anonymous_linux.webanlimax'

        return [game_exec,game_path,game_link, game_package]
    
    if game == 'nightsoul':

        print('Use Night soul')

        if platform == 'nt':
            
            game_link = 'https://github.com/evembar/webanlauncher/releases/download/gamebox/night_soul_windows.zip'

            game_exec = 'Night Soul.exe'

            game_path = 'night_soul'

            game_package = 'night_soul_windows.zip'

        elif platform == 'posix':

            game_link = 'https://github.com/evembar/webanlauncher/releases/download/gamebox/night_soul_linux.zip'

            game_exec = 'night_soul.appimage'

            game_path = 'night_soul'

            game_package = 'night_soul_linux.zip'

        return [game_exec,game_path,game_link, game_package]
    
    if game == 'andlc':
        game_exec='none'
        game_path='none'
        game_link='none'
        game_package='none'
        return [game_exec,game_path,game_link, game_package]
    if game == 'ortano':
        game_exec='none'
        game_path='none'
        game_link='none'
        game_package='none'
        return [game_exec,game_path,game_link, game_package]
    
def link_theme(target):
    if target=='white':
        return 'https://github.com/evembar/webanlauncher/raw/main/theme/white.zip'
    elif target=='black':
        return 'https://github.com/evembar/webanlauncher/raw/main/theme/black.zip'